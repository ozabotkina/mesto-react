
import '../index.css';
import Header from './Header';
import Main from './Main';
import Footer from './Footer';
import PopupWithForm from "./PopupWithForm"
import ImagePopup from "./ImagePopup"
import React from 'react';
import ReactDOM from 'react-dom/client';


function App() {


let isEditProfileOpen = false;
let isEditAvatarPopupOpen = false;
let isAddCardOpen = false;

function handleEditAvatarClick(){
  console.log(isEditAvatarPopupOpen);
  isEditAvatarPopupOpen = !isEditAvatarPopupOpen;
  console.log(isEditAvatarPopupOpen);
}
  

function handleEditProfileClick(){
    console.log(isEditProfileOpen);
    isEditProfileOpen = !isEditProfileOpen;
    console.log(isEditProfileOpen)};

function handleAddPlaceClick(){

  console.log(isAddCardOpen);
  isAddCardOpen = !isAddCardOpen;
  console.log(isAddCardOpen)};



  return (
  <div className="page">
    <Header />
    <Main 
    onEditProfile ={() => handleEditProfileClick()}
    onAddPlace = {() => handleAddPlaceClick()}
    onEditAvatar = {() => handleEditAvatarClick()} />

    <PopupWithForm 
    name="author" 
    title="Редактировать профиль" 
    children= 
    {<><input type="text" id="name" name="popup__name" className="popup__name popup__input" minLength="2" maxLength="40" required />
    <span className="popup__error name-error popup__error_visible"></span>
    <input type="text" id="about" name="popup__about" className="popup__about popup__input"  minLength="2" maxLength="200" required />
    <span className="popup__error about-error popup__error_visible"></span></>}
    button="Сохранить"
    isOpen = {isEditProfileOpen}
    />
    
    <PopupWithForm 
    name="avatar" 
    title="Обновить аватар" 
    children= 
    {<><input type="url" id="alink" name="avatarlink" className="popup__name popup__input" placeholder="Ссылка на аватар" required />
    <span className="popup__error alink-error popup__error_visible"></span></>}
    button="Сохранить"
    isOpen = {isEditAvatarPopupOpen}
    />

    <PopupWithForm 
    name="new-card" 
    title="Новое место" 
    children= 
    {<><input type="text" id="cardname" name="cardname" className="popup__name popup__input" placeholder="Название" minLength="2" maxLength="30" required />
    <span className="popup__error cardname-error popup__error_visible"></span>
    <input type="url" id="link" name="cardlink" className="popup__about popup__input" placeholder="Ссылка на картинку" required />
    <span className="popup__error link-error popup__error_visible"></span>
    </>}
    button="Создать"
    isOpen = {isAddCardOpen}

    />

    <PopupWithForm 
    name="delete-card" 
    title="Вы уверены?" 
    children= 
    {<><input type="text" id="cardname" name="cardname" className="popup__name popup__input" placeholder="Название" minLength="2" maxLength="30" required />
    <span className="popup__error cardname-error popup__error_visible"></span>
    <input type="url" id="link" name="cardlink" className="popup__about popup__input" placeholder="Ссылка на картинку" required />
    <span className="popup__error link-error popup__error_visible"></span>
    </>}
    button="Да"
    isOpen = {false}

    />

    <ImagePopup/>
        

    <Footer />
  </div>
  );
}

export default App;
