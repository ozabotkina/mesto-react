function ImagePopup() {
 return (  
   <div className="popup image-popup">
    <div className="image-popup__wrap">
      <button className="popup__close-icon image-popup__close interactive" type="button"></button>
      <img className="image-popup__image" src="#" alt="" />
      <p className="image-popup__comment"></p>
    </div>
  </div>  
  )
}
export default ImagePopup