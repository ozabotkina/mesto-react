import PopupWithForm from "./PopupWithForm"
import ImagePopup from "./ImagePopup"

function Main(props){




    return (      
        <main className="content">
        <section className="profile">
          <div className ="profile__avatar-wrap" onClick={props.onEditAvatar}>
            <img className="profile__avatar" src="./images/Avatar.png" alt="Фото автора" />
            <img className="profile__edit" src="./images/pencil.svg" />
          </div>
          <div className="profile__info">
            <div className="profile__name-wrap">
              <h1 className="profile__name">Жак-Ив</h1>
              <button className="edit-button interactive" type="button" onClick={props.onEditProfile}></button>
            </div>
            <p className="profile__about"></p>
          </div>    
          <button className="add-button interactive" type="button" onClick={props.onAddPlace}></button>
        </section>    
    
        <section className="elements">
          <template id="card-element">
            <div className="element">
              <button className="element__trash interactive" type="button"></button>
              <img className="element__image" src="#" alt=" " />
              <div className="element__words">
                <h2 className="element__title"></h2>
                <div className="element__like-info">
                <button className="element__like interactive" type="button"></button>
                <p className="element__like-number">3</p>
                </div>
                </div>
             </div>   
          </template>
        </section>
    
    <PopupWithForm 
    name="author" 
    title="Редактировать профиль" 
    children= 
    {<><input type="text" id="name" name="popup__name" className="popup__name popup__input" minLength="2" maxLength="40" required />
    <span className="popup__error name-error popup__error_visible"></span>
    <input type="text" id="about" name="popup__about" className="popup__about popup__input"  minLength="2" maxLength="200" required />
    <span className="popup__error about-error popup__error_visible"></span></>}
    button="Сохранить"
    isOpen = {false}
    />
    
    <PopupWithForm 
    name="avatar" 
    title="Обновить аватар" 
    children= 
    {<><input type="url" id="alink" name="avatarlink" className="popup__name popup__input" placeholder="Ссылка на аватар" required />
    <span className="popup__error alink-error popup__error_visible"></span></>}
    button="Сохранить"
    isOpen = {false}
    />

    <PopupWithForm 
    name="new-card" 
    title="Новое место" 
    children= 
    {<><input type="text" id="cardname" name="cardname" className="popup__name popup__input" placeholder="Название" minLength="2" maxLength="30" required />
    <span className="popup__error cardname-error popup__error_visible"></span>
    <input type="url" id="link" name="cardlink" className="popup__about popup__input" placeholder="Ссылка на картинку" required />
    <span className="popup__error link-error popup__error_visible"></span>
    </>}
    button="Создать"
    isOpen = {false}

    />

    <PopupWithForm 
    name="delete-card" 
    title="Вы уверены?" 
    children= 
    {<><input type="text" id="cardname" name="cardname" className="popup__name popup__input" placeholder="Название" minLength="2" maxLength="30" required />
    <span className="popup__error cardname-error popup__error_visible"></span>
    <input type="url" id="link" name="cardlink" className="popup__about popup__input" placeholder="Ссылка на картинку" required />
    <span className="popup__error link-error popup__error_visible"></span>
    </>}
    button="Да"
    isOpen = {false}

    />

    <ImagePopup/>
        
    
      </main>
    )
}

export default Main